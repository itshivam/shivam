
------(1)
select FirstName,Name from person.person a full join Sales.Store b on a.BusinessEntityID= b.BusinessEntityID
------(2)
select orderdate, OrderQty as "Number of Orders" from sales.SalesOrderHeader a join sales.SalesOrderDetail b on a.SalesOrderID=b.SalesOrderID
------(3)
select CustomerID,OrderQty from  sales.salesorderdetail a join sales.SalesOrderHeader b on a.SalesOrderID=b.SalesOrderID


